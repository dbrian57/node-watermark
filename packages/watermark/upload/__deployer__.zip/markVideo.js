var ffmpeg = require("ffmpeg")

async function markVideo(file) {
    const video = await new ffmpeg(file)
    const watermarkPath = "sammy.png"
    const newFilepath = "watermarked_video.mp4"

    var settings = {
        position: "SE", // Position: NE NC NW SE SC SW C CE CW
        margin_nord: null, // Margin north
        margin_sud: null, // Margin south
        margin_east: null, // Margin east
        margin_west: null // Margin west
    }

    // creates watermarked video
    const markedVideo = video.fnAddWatermark(watermarkPath, newFilepath, settings);
    return markedVideo;
}

exports.markVideo = markVideo